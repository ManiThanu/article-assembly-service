# MSYN Bookshelf Modelbase
## Installing
    $ npm install msyn-bookshelf-modelbase --save

## Publishing
### Step 1: Obtain NPM Credentials
    $ curl -u synusr:askmaniforpw https://artprod.dev.bloomberg.com/artifactory/api/npm/auth

### Step 2: Update .npmrc
Add the response from Step 1 to the `.npmrc` file in your home directory.

### Step 3: Publish
    $ npm publish --registry https://artprod.dev.bloomberg.com/artifactory/api/npm/bb-npmjs-local

Source: https://cms.prod.bloomberg.com/team/pages/viewpage.action?pageId=491036581#Artifactory-Npm(JavascriptPackageManager)-NPMregistryforpublishingpackages
