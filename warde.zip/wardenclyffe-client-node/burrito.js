import fetch from 'node-fetch';

const TIMEOUT = 5000;

function base64(string) {
  return new Buffer(string, 'binary').toString('base64');
}

export default class {
  constructor({ url, username, password, timeout = TIMEOUT }) {
    this.url = url.endsWith('/') ? url : `${url}/`;
    this.options = {
      timeout,
      headers: {
        Authorization: `Basic ${base64(`${username}:${password}`)}`,
      },
    };
  }

  endpoint(schema) {
    const { url } = this;
    const query = encodeURIComponent(schema);

    return `${url}?query=${query}`;
  }

  fetch(schema) {
    const url = this.endpoint(schema);
    const { options } = this;

    return fetch(url, options)
            .then(data => data.json());
  }
};
