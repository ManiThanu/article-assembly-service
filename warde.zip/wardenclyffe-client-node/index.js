'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _nodeFetch = require('node-fetch');

var _nodeFetch2 = _interopRequireDefault(_nodeFetch);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var TIMEOUT = 5000;

function base64(string) {
  return new Buffer(string, 'binary').toString('base64');
}

var _class = function () {
  function _class(_ref) {
    var url = _ref.url;
    var username = _ref.username;
    var password = _ref.password;
    var _ref$timeout = _ref.timeout;
    var timeout = _ref$timeout === undefined ? TIMEOUT : _ref$timeout;

    _classCallCheck(this, _class);

    this.url = url.endsWith('/') ? url : url + '/';
    this.options = {
      timeout: timeout,
      headers: {
        Authorization: 'Basic ' + base64(username + ':' + password)
      }
    };
  }

  _createClass(_class, [{
    key: 'endpoint',
    value: function endpoint(schema) {
      var url = this.url;

      var query = encodeURIComponent(schema);

      return url + '?query=' + query;
    }
  }, {
    key: 'fetch',
    value: function fetch(schema) {
      var url = this.endpoint(schema);
      var options = this.options;


      return (0, _nodeFetch2.default)(url, options).then(function (data) {
        return data.json();
      });
    }
  }]);

  return _class;
}();

exports.default = _class;
;
