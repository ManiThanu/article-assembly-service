# Install
```
npm install wardenclyffe-client-node
```

# Usage
```node
import WardenclyffeClient from 'wardenclyffe-client-node';

const config = {
  url: 'https://wardenclyffe.bloomberg.com',
  username: 'DAPER_USERNAME',
  password: 'DAPER_PASSWORD',
  timeout: 5000, // optional
};

const wardenclyffe = new WardenclyffeClient(config);

async function stories() {
  const schema = `
    {
      stories(site: GADFLY, limit: 1) {
        id
      }
    }
  `;

  const response = await wardenclyffe.fetch(schema);
  
  return response;
}
```

# Publish
When you make changes, you can update the package using npm version <update_type>, where update_type is one of the semantic versioning release types, `patch`, `minor`, or `major`. This command will change the version number in package.json. Note that this will also add a tag with this release number to your git repository if you have one.

After updating the version number, you can `npm publish` again.
