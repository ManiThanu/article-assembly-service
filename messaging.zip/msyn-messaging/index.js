/* eslint-disable */

// Require Babel Polyfill If Not Already Loaded
if (!global._babelPolyfill) {
  require('babel-polyfill');
}

// Wrap Original ES6 Export for Universal Use
module.exports = require('./build/messaging/index.js').default;
