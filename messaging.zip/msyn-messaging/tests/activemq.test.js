import assert             from 'assert';
import ActiveMQConnection from '../src/messaging/connections/activemq';
import ActiveMQSender     from '../src/messaging/senders/activemq';
import ActiveMQReceiver   from '../src/messaging/receivers/activemq';

import { delay, messageProcessor } from './helpers';

describe('ActiveMQ', () => {
  before(() => {
    global.amqConnection = new ActiveMQConnection();
    global.messages      = [
      // [message, headers]
      [{ message: `AMQ Message 1 - @ ${time()}` }, { custom_header: 'amq1' }],
      [{ message: `AMQ Message 2 - @ ${time()}` }, { custom_header: 'amq2' }],
      [`AMQ Message 3 - @ ${time()}`, { custom_header: 'amq3' }],
      [`AMQ Message 4 - @ ${time()}`, { custom_header: 'amq4' }],
    ];
  });

  after(() => {
    delete global.amqConnection;
    delete global.messages;
  });

  it('should send to queue', async () => {
    const sender = new ActiveMQSender({
      destination: '/queue/test',
      connectionManager: amqConnection,
    });

    // Connect
    await sender.connect();

    // Send
    await Promise.all(messages.map(async message => assert(await sender.send(...message))));
  });

  it('should receive from queue', async () => {
    const received = [];
    const receiver = new ActiveMQReceiver({
      destination: '/queue/test',
      connectionManager: amqConnection,
      processor: (message) => {
        received.push(message);
        return messageProcessor(message);
      },
    });

    // Connect
    await receiver.connect();

    // Receive
    receiver.receive();
    await delay();

    // Assert
    assert.deepEqual(
      received.map(message => message.headers.custom_header).sort(),
      messages.map(message => message[1].custom_header).sort(),
    );

    // Auto-Disconnect
    // https://github.com/gdaws/node-stomp/blob/master/docs/sources/api/channel-pool.md
  });

  it('should publish/subscribe to topic', async () => {
    const sender = new ActiveMQSender({
      destination: '/topic/test',
      connectionManager: amqConnection,
    });

    const received = [];
    const receiver = new ActiveMQReceiver({
      destination: '/topic/test',
      connectionManager: amqConnection,
      processor: (message) => {
        received.push(message);
        return messageProcessor(message);
      },
    });

    // Connect
    await sender.connect();
    await receiver.connect();

    // Send/Receive (i.e. Publish/Subscribe)
    receiver.receive();
    await Promise.all(messages.map(async message => assert(await sender.send(...message))));

    // Assert
    assert.deepEqual(
      received.map(message => message.headers.custom_header).sort(),
      messages.map(message => message[1].custom_header).sort(),
    );

    // Auto-Disconnect
    // https://github.com/gdaws/node-stomp/blob/master/docs/sources/api/channel-pool.md
  });
});
