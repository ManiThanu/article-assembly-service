import assert           from 'assert';
import RabbitMQSender   from '../src/messaging/senders/rabbitmq';
import RabbitMQReceiver from '../src/messaging/receivers/rabbitmq';

import { delay, messageProcessor } from './helpers';

describe('RabbitMQ', () => {
  before(() => {
    global.messages = [
      // [message, headers]
      [{ message: `RMQ Message 1 - @ ${time()}` }, { custom_header: 'rmq1' }],
      [{ message: `RMQ Message 2 - @ ${time()}` }, { custom_header: 'rmq2' }],
      [`RMQ Message 3 - @ ${time()}`, { custom_header: 'rmq3' }],
      [`RMQ Message 4 - @ ${time()}`, { custom_header: 'rmq4' }],
    ];
  });

  after(() => {
    delete global.messages;
  });

  it('should send to queue', async () => {
    // Sender Using 'queueName'
    const sender = new RabbitMQSender({
      exchangeName: 'testing',
      queueName: 'test',
    });

    // Sender Using 'destination'
    const sender2 = new RabbitMQSender({
      exchangeName: 'testing',
      destination: '/queue/test',
    });

    // Connect
    await sender.connect();
    await sender2.connect();

    // Send
    await Promise.all(
      messages.slice(0, 3).map(async message => assert(await sender.send(...message))),
    );

    // Send via 'destination'
    assert(await sender2.send(...messages[3]));

    // Disconnect
    await sender.channel.close();
    await sender2.channel.close();
  });

  it('should receive from queue', async () => {
    const received = [];
    const receiver = new RabbitMQReceiver({
      exchangeName: 'testing',
      queueName: 'test',
      acknowledge: true,
      processor: (message) => {
        received.push(message);
        return messageProcessor(message);
      },
    });

    // Connect
    await receiver.connect();

    // Receive
    await receiver.receive();
    await delay();

    // Assert
    assert.deepEqual(
      received.map(message => message.headers.custom_header).sort(),
      messages.map(message => message[1].custom_header).sort(),
    );

    // Disconnect
    await receiver.channel.close();
  });
});
