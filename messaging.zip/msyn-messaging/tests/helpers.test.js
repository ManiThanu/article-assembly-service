/* eslint-disable no-useless-escape, quotes*/

import assert  from 'assert';
import Helpers from '../src/messaging/helpers/index';

describe('Helpers', () => {
  describe('toJS()', () => {
    it('should parse object strings', () => {
      const result = Helpers.toJS("{\'foo\': \'bar\', \'a\': [\'1\',\'2\',\'3\']}");
      assert(typeof (result) === 'object');
    });

    it('should parse array strings', () => {
      const result = Helpers.toJS("[\'1\',\'2\',\'3\']");
      assert(result.constructor.name === 'Array');
    });

    it('should parse boolean strings', () => {
      const result  = Helpers.toJS("true");
      const result2 = Helpers.toJS("false");
      assert(result === true);
      assert(result2 === false);
    });

    it('should parse number strings', () => {
      const result = Helpers.toJS("10");
      assert(result === 10);
    });
  });
});
