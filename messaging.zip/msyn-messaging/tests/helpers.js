// Universal Message Processor
export async function messageProcessor(message) {
  const { payload } = message;
  await console.log('[received message]:', payload);
  return payload;
}

// Simulated Delay
export function delay(ms = 3000) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
