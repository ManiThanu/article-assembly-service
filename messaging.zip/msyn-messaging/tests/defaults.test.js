import assert            from 'assert';
import DefaultConnection from '../src/messaging/connections/default';
import DefaultSender     from '../src/messaging/senders/default';
import DefaultReceiver   from '../src/messaging/receivers/default';

import { delay, messageProcessor } from './helpers';

describe('Default Sender/Receiver', () => {
  before(() => {
    global.defaultConnection = new DefaultConnection();
    global.messages = [
      // [message, headers]
      [{ message: `Default Message 1 - @ ${time()}` }, { custom_header: 'd1' }],
      [{ message: `Default Message 2 - @ ${time()}` }, { custom_header: 'd2' }],
      [`Default Message 3 - @ ${time()}`, { custom_header: 'd3' }],
      [`Default Message 4 - @ ${time()}`, { custom_header: 'd4' }],
    ];
  });

  after(() => {
    delete global.defaultConnection;
    delete global.messages;
  });

  it('should send to queue', async () => {
    const sender = new DefaultSender({
      destination: '/queue/test.default',
      connectionManager: defaultConnection,
    });

    // Connect
    await sender.connect();

    // Send
    await Promise.all(messages.map(async message => assert(await sender.send(...message))));
  });

  it('should receive from queue', async () => {
    const received = [];
    const receiver = new DefaultReceiver({
      destination: '/queue/test.default',
      acknowledge: true,
      connectionManager: defaultConnection,
      processor: (message) => {
        received.push(message);
        return messageProcessor(message);
      },
    });

    // Connect
    await receiver.connect();

    // Receive
    receiver.receive();
    await delay();

    // Assert
    assert.deepEqual(
      received.map(message => message.headers.custom_header).sort(),
      messages.map(message => message[1].custom_header).sort(),
    );
  });
});
