/**
 * Global Before Hooks/Helpers (Run Before Any Tests Begin)
 */
before(() => {
  // Timestamp Helper
  global.time = () => (new Date()).toISOString();
});

after(() => {
  delete global.time;
});
