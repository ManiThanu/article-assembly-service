/* eslint-disable no-param-reassign, arrow-body-style */

import BaseHelper      from '../helpers';
import ActiveMQHelpers from '../helpers/activemq';
import ReceiverHelpers from '../helpers/receivers';

/**
 * Base ActiveMQ Receiver
 */

class ActiveMQReceiver {
 /**
  * Instantiates Message Receiver
  * @param opts {string} destination - queue/topic path
  * @param opts {ActiveMQConnection} connectionManager
  * @param opts {boolean} acknowledge - enables ack/nack
  * @returns {object} self
  */
  constructor(opts = {}) {
    // Assign Attributes
    Object.assign(this, { acknowledge: true }, opts);

    // Ensure Headers
    this.headers = {
      destination: this.destination,
      ack: 'client-individual',
      'content-type': 'application/json',
      ...this.headers,
    };

    // Validate
    this.validate();
  }

 /**
  * Consumes Messages For Broker Destination
  * @returns {object} subscription - pointer to close polling process: { cancel(), unsubscribe() }
  */
  receive() {
    const self = this;
    console.log(`[*] Waiting for ActiveMQ messages in ${this.headers.destination}`);
    return this.channel.subscribe(this.headers, (subscribeError, message /* subscription */) => {
      if (subscribeError) {
        console.error('Receive Error: ', subscribeError.message);
      }
      return message.readString('utf-8', (readError, payload) => {
        if (readError) {
          console.error('Receive Error: ', readError.message);
        }

        // Process
        return self.processor(self.normalizeMessage('ActiveMQ', message, payload))
          .then(() => {
            return self.acknowledge ? self.channel.ack(message) : null;
          })
          .catch((e) => {
            console.error(`Processing Error: ${this.destination} - `, e.message);
            return self.acknowledge ? self.channel.nack(message) : null;
          });
      });
    });
  }
}

// Apply Helpers
BaseHelper.applyInstanceHelpers(
  ActiveMQReceiver,
  ActiveMQHelpers.instanceHelpers,
  ReceiverHelpers.instanceHelpers,
);

export default ActiveMQReceiver;
