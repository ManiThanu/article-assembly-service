/* eslint-disable no-multi-spaces, consistent-return */

import RabbitMQConnection from '../connections/rabbitmq';
import BaseHelper         from '../helpers';
import RabbitMQHelpers    from '../helpers/rabbitmq';
import ReceiverHelpers    from '../helpers/receivers';

/**
 * Base RabbitMQ Receiver
 */

class RabbitMQReceiver {
 /**
  * Instantiates Message Receiver
  * @param opts {string} destination
  * @param opts {ActiveMQConnection} connectionManager
  * @param opts {string} exchangeName
  * @param opts {string} queueName
  * @param opts {boolean} acknowledge
  * @param opts {string} routingKey
  * @param opts {object} bindArgs
  * @returns {object} self
  */
  constructor(opts = {}) {
    // Assign Attributes
    Object.assign(this, opts);

    // Attempt Destination Detection
    this.detectDestination();

    // Validate
    this.validate();
  }

 /**
  * Ensures Broker Connectivity
  * @returns {Promise} self
  */
  connect() {
    return RabbitMQConnection.connect(this);
  }

 /**
  * Consumes Messages For Given Broker Destination
  * @todo: ensure we're consuming correctly so we can complete the abstraction (e.g. bindQueue)
  * @see: 'noAck' has a different meaning than you might expect. With RabbitMQ/AMQP-Node, it
  *       indicates whether you WILL acknowledge a message, not that you DO acknowledge a
  *       message. Please see the following docs for specific details:
  *       http://www.squaremobius.net/amqp.node/channel_api.html#channel_consume
  */
  async receive() {
    try {
      // Apply Channel Settings (applied to both the initial connection & all reconnections)
      this.channel.addSetup((channel) => {
        const settings = [];

        if (this.exchangeName) {
          // Assert Exchange
          settings.push(channel.assertExchange(
            this.exchangeName,
            'topic',
            { durable: true },
          ));

          // Bind Queue
          if (this.bindArgs && this.routingKey) {
            settings.push(channel.bindQueue(
              this.queueName,
              this.exchangeName,
              this.routingKey,
              this.bindArgs,
            ));
          }
        }

        // Start Consumer
        settings.push(channel.consume(
          this.queueName,
          async (message) => {
            try {
              return await this.processor(this.normalizeMessage('RabbitMQ', message));
            } catch (e) {
              console.error(`Processing Error: ${this.destination || this.queueName} - `, e.message);
            }
          },
          { noAck: this.acknowledge },
        ));

        return Promise.all(settings);
      });

      // Connect Via Connection Manager Wrapper
      console.log(`[*] Waiting for RabbitMQ messages in ${this.destination || this.queueName}`);
      await this.channel.waitForConnect();
    } catch (e) {
      console.error('Receive Error: ', e.message);
    }
  }
}

// Apply Helpers
BaseHelper.applyInstanceHelpers(
  RabbitMQReceiver,
  RabbitMQHelpers.instanceHelpers,
  ReceiverHelpers.instanceHelpers,
);

export default RabbitMQReceiver;
