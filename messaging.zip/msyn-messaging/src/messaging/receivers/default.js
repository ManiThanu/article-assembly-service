import Receiver from './activemq';

/**
 * Default Receiver (Broker Agnostic)
 */

class DefaultReceiver extends Receiver {}

export default DefaultReceiver;
