import Sender from './activemq';

/**
 * Default Sender (Broker Agnostic)
 */

class DefaultSender extends Sender {}

export default DefaultSender;
