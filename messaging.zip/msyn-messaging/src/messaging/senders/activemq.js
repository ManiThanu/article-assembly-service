/* eslint-disable no-param-reassign */

import uuid            from 'uuid/v4';
import BaseHelper      from '../helpers';
import ActiveMQHelpers from '../helpers/activemq';
import SenderHelpers   from '../helpers/senders';

/**
 * Base ActiveMQ Sender
 */

class ActiveMQSender {
 /**
  * Instantiates Message Sender
  * @param opts {string} destination
  * @param opts {ActiveMQConnection} connectionManager
  * @returns {object} self
  */
  constructor(opts = {}) {
    // Assign Attributes
    Object.assign(this, opts);

    // Ensure Headers
    this.headers = {
      persistent: true,
      destination: this.destination,
      'content-type': 'application/json',
      ...this.headers,
    };

    // Validate
    this.validate();
  }

 /**
  * Sends Message To Broker Destination
  * @param {string} payload - message payload
  * @param {object} headers - custom headers
  * @returns {Promise} payload
  */
  send(payload, headers = {}) {
    // Ensure Correlation ID
    headers.correlation_id = headers.correlation_id || uuid();

    return new Promise((resolve, reject) => {
      this.channel.send(
        { ...this.headers, ...headers }, // headers
        this.stringifyPayload(payload),  // payload
        (error) => {
          if (error) {
            console.error('Send Failure: ', error.message);
            reject(error);
          }
          resolve(payload);
        },
      );
    });
  }
}

// Apply Helpers
BaseHelper.applyInstanceHelpers(
  ActiveMQSender,
  ActiveMQHelpers.instanceHelpers,
  SenderHelpers.instanceHelpers,
);

export default ActiveMQSender;
