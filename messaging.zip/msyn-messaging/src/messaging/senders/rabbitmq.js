import RabbitMQConnection from '../connections/rabbitmq';
import BaseHelper         from '../helpers';
import RabbitMQHelpers    from '../helpers/rabbitmq';
import SenderHelpers      from '../helpers/senders';

/**
 * Base RabbitMQ Sender
 */

class RabbitMQSender {
 /**
  * Instantiates Message Sender
  * @param opts {string} destination
  * @param opts {ActiveMQConnection} connectionManager
  * @param opts {string} exchangeName
  * @param opts {string} queueName
  * @returns {object} self
  */
  constructor(opts = {}) {
    // Assign Attributes
    Object.assign(this, opts);

    // Attempt Destination Detection
    this.detectDestination();

    // Validate
    this.validate();
  }

 /**
  * Ensures Broker Connectivity
  * @returns {Promise} self
  */
  async connect() {
    await RabbitMQConnection.connect(this);
    await this.channel.waitForConnect();
    return this;
  }

 /**
  * Sends Message To Broker Destination
  * @param {string} payload - message payload
  * @param {object} headers - custom headers
  * @returns {Promise} payload
  */
  send(payload, headers = {}) {
    try {
      // Note: Headers get embedded under properties
      return this.channel.sendToQueue(
        this.queueName,                 // destination
        this.stringifyPayload(payload), // payload
        { headers },                    // headers
      );
    } catch (e) {
      console.error('Send Failure: ', e.message);
      return e;
    }
  }
}

// Apply Helpers
BaseHelper.applyInstanceHelpers(
  RabbitMQSender,
  RabbitMQHelpers.instanceHelpers,
  SenderHelpers.instanceHelpers,
);

export default RabbitMQSender;
