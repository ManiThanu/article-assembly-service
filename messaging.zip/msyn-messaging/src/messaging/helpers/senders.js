/**
 * Sender Helpers
 */

/**
 * Ensures Payload is Stringified
 * @desc The underlying libs need stringified payloads...
 * @param {object|string} payload
 * @returns {string} payload
 */
function stringifyPayload(payload) {
  return typeof (payload) === 'string' ? payload : JSON.stringify(payload);
}

export default {
  // Instance Helpers
  instanceHelpers: { stringifyPayload },
  // Class Helpers
  classHelpers: {},
};
