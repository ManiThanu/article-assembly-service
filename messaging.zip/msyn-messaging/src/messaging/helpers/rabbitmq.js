/**
 * RabbitMQ Helpers
 */

/**
 * Detects Queue/Topic Name From Destination
 * @type: Prototype Helper
 * @desc: The underlying amqp.node lib has a different API for sending to queues & topics.
 *        As such, we must manually distinguish/delegate to keep the high level API clean
 * @returns {object} self
 */
function detectDestination() {
  if (!this.queueName && `${this.destination}`.match('/')) {
    // destinationName will become 'q-name' for either 'queue/q-name' or '/queue/q-name' inputs
    const [type, destinationName] = this.destination.replace(/^\//, '').split('/');
    switch (type) {
      case 'queue':
        this.queueName = destinationName;
        break;
      case 'topic':
        throw new Error('RabbitMQ topics are not currently supported.');
      default:
        break;
    }
  }
  return this;
}

/**
 * Ensures Valid Headers & Configs
 * @returns {boolean}
 */
function validate() {
  if (!this.destination && !this.queueName) {
    throw new Error('Validation Error: Missing destination queue/topic');
  }
  return true;
}

export default {
  // Instance Helpers
  instanceHelpers: { detectDestination, validate },
  // Class Helpers
  classHelpers: {},
};
