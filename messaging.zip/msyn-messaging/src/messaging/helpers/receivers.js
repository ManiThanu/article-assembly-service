/**
 * Receiver Helpers
 */

/**
 * Default Processor For Consumed Messages
 * @type Prototype Helper
 * @param {object} message
 * @returns {Promise<string|object>} payload
 * @see this is meant to be overridden
 */
async function processor(message) {
  console.warn(`
    The default processor has been called. To use a custom processor,
    please override the 'processor' method in your subclass or instance.`,
  );
  const { payload } = message;
  console.log('[consumed message]:', payload);
  return payload;
}

/**
 * Attempts Payload JSON Conversion
 * @desc The underlying libs stringify the payloads. This function attempts to convert them
 *       to JSON whenever it can.
 * @param {string|object} payload
 * @returns {string|object} parsed
 */
function parsePayload(payload) {
  try {
    return JSON.parse(payload);
  } catch (e) {
    return payload;
  }
}

/**
 * Standardizes Message
 * @type: Prototype Helper
 * @desc: Every broker/underlying-lib formats messages differently. This function aims
 *        to abstract away the delta and give receivers a common interface.
 * @param {object} message
 * @param {broker} string
 * @returns {object} message - standardized format { headers: {}, payload: {} }
 */
function normalizeMessage(broker, message, payload) {
  switch (broker) {
    case 'RabbitMQ':
      return {
        headers: message.properties.headers,
        payload: parsePayload(message.content || payload),
      };
    case 'ActiveMQ':
      return {
        headers: message.headers,
        payload: parsePayload(payload),
      };
    default:
      throw new Error(console.error(`Unsupported Broker: ${broker}`));
  }
}

export default {
  // Instance Helpers
  instanceHelpers: { processor, normalizeMessage },
  // Class Helpers
  classHelpers: {},
};
