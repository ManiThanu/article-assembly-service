/**
 * Universal/Base Helper
 */

/**
 * Adds Given Class (Static) Helper Set to Class
 * @type: Static Helper
 * @param {class|object} scope - class or object
 * @param {object} helpers - static helpers (e.g. { helper: fn(), helper2: fn() }, ...)
 * @returns {object} self
 */
function applyClassHelpers(scope, ...helpers) {
  Object.assign(scope, ...helpers);
  return scope;
}

/**
 * Adds Given Instance (Prototype) Helper Set to Class
 * @type: Static Helper
 * @param {class|function} scope - prototype-able entity
 * @param {object} helpers - prototype helpers (e.g. { helper: fn(), helper2: fn() }, ...)
 * @returns {object} self
 */
function applyInstanceHelpers(scope, ...helpers) {
  Object.assign(scope.prototype, ...helpers);
  return scope;
}

/**
 * Converts Stringified Number, Array, Object, or Boolean to Native JS Object
 * @type: Static Helper
 * @param {string} string
 * @returns {object|array|boolean|number}
 * @see: this should really only be used for small/simple parsings (e.g. ENV variables)
 */
function toJS(string) {
  return JSON.parse(string.replace(/'/g, '"'));
}

export default {
  applyClassHelpers,
  applyInstanceHelpers,
  toJS,
};
