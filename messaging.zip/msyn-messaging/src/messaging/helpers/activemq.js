import ActiveMQConnection from '../connections/activemq';

/**
 * ActiveMQ Helpers
 */

/**
 * Ensures Valid Headers & Configs
 * @type: Prototype Helper
 * @returns {boolean}
 */
function validate() {
  if (!this.destination) {
    throw new Error('Validation Error: Missing destination queue/topic');
  }
  return true;
}

/**
 * Ensures Broker Connectivity
 * @type: Prototype Helper
 * @returns {Promise} self
 */
function connect() {
  return ActiveMQConnection.connect(this);
}

export default {
  // Instance Helpers
  instanceHelpers: { validate, connect },
  // Class Helpers
  classHelpers: {},
};
