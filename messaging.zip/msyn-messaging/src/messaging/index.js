/* eslint-disable key-spacing */

// Connections
import ActiveMQConnection from './connections/activemq';
import RabbitMQConnection from './connections/rabbitmq';
import DefaultConnection  from './connections/default';

// Senders
import ActiveMQSender  from './senders/activemq';
import RabbitMQSender  from './senders/rabbitmq';
import DefaultSender   from './senders/default';

// Receivers
import ActiveMQReceiver from './receivers/activemq';
import RabbitMQReceiver from './receivers/rabbitmq';
import DefaultReceiver  from './receivers/default';

export default {
  connections: {
    ActiveMQ: ActiveMQConnection,
    RabbitMQ: RabbitMQConnection,
    Default:  DefaultConnection,
  },
  senders: {
    ActiveMQ: ActiveMQSender,
    RabbitMQ: RabbitMQSender,
    Default:  DefaultSender,
  },
  receivers: {
    ActiveMQ: ActiveMQReceiver,
    RabbitMQ: RabbitMQReceiver,
    Default:  DefaultReceiver,
  },
};
