/* eslint-disable no-param-reassign, no-multi-spaces */

import util       from 'util';
import AMPQ       from 'amqp-connection-manager';
import BaseHelper from '../helpers';

/**
 * Base RabbitMQ Connection
 */

class RabbitMQConnection {
 /**
  * Instantiates Connection Manager For Connectionless Channel Pool
  * @returns {object} self
  */
  constructor() {
    // Create Connection (via Underlying AMPQ Connection Manager)
    this.connection = AMPQ.connect(RabbitMQConnection.detectNodes(), {
      json: true,
      heartbeatIntervalInSeconds: Number(process.env.rmq_heartbeat || 5),
    });
  }

 /**
  * Detects Connectable Broker Nodes
  * @returns {array<string>} nodes
  */
  static detectNodes() {
    const hosts = BaseHelper.toJS(`${process.env.rmq_hosts}`);
    if (!hosts.length) {
      throw new Error('process.env.rmq_hosts is not set');
    }
    return hosts.map(host => RabbitMQConnection.buildNode(host));
  }

 /**
  * Builds Config For Connectable Broker Node
  * @param {string} host
  * @returns {string} node - AMQP Connection URI
  */
  static buildNode(host) {
    return util.format('amqp://%s:%s@%s:%s/%s',
      process.env.rmq_username,
      process.env.rmq_password,
      host,
      process.env.rmq_port,
      process.env.rmq_vhost,
    ).replace(/\/undefined$/, ''); // optional vhost
  }

 /**
  * Ensures Broker Connectivity
  * @param {RabbitMQSender|RabbitMQReceiver} - client
  * @returns {Promise} client
  */
  static async connect(client) {
    try {
      // Ensure Connection Manager
      client.connectionManager = (client.connectionManager || (new RabbitMQConnection()));

      // Ensure Connection
      await client.connectionManager.connection;

      // Ensure Channel
      client.channel = await (client.channel || client.connectionManager.connection.createChannel({
        json: true,
       /**
        * @param {object} channel - amqplib channel instance
        */
        setup: channel => channel.assertQueue(client.queueName),
      }));
    } catch (e) {
      console.log(`Connection Error: ${e.message}`);
    }
    return client;
  }
}

export default RabbitMQConnection;
