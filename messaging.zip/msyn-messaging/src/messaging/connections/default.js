import Connection from './activemq';

/**
 * Default Sender (Broker Agnostic)
 */

class DefaultConnection extends Connection {}

export default DefaultConnection;
