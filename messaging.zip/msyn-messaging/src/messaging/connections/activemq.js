/* eslint-disable no-param-reassign, no-multi-spaces */

import STOMP      from 'stompit';
import BaseHelper from '../helpers';

/**
 * Base ActiveMQ Connection
 */

class ActiveMQConnection {
 /**
  * Instantiates Connection Manager w/ Failover & Connectionless Channel Pool
  * @returns {object} self
  * @todo: Add support for checking/re-initializing closed channels/pools
  */
  constructor() {
    // Create Connection (via Underlying STOMP Connection Manager)
    this.connection = new STOMP.ConnectFailover(ActiveMQConnection.detectNodes());

    // Create Channel Pool
    this.channelPool = new STOMP.ChannelPool(this.connection);

    // Create Channel
    this.channel = new Promise((resolve, reject) => {
      this.channelPool.channel((error, channel) => {
        if (error) {
          reject(error);
        }
        resolve(channel);
      });
    });

    return this;
  }

 /**
  * Detects Connectable Broker Nodes
  * @returns {array<object>} nodes
  */
  static detectNodes() {
    const hosts = BaseHelper.toJS(`${process.env.amq_hosts}`);
    if (!hosts.length) {
      throw new Error('process.env.amq_hosts is not set');
    }
    return hosts.map(host => ActiveMQConnection.buildNode(host));
  }

 /**
  * Builds Config For Connectable Broker Node
  * @param {string} host
  * @returns {object} node - STOMP Connection Config
  */
  static buildNode(host) {
    return {
      host,
      port: process.env.amq_port,
      connectHeaders: {
        login: process.env.amq_username,
        passcode: process.env.amq_password,
        'heart-beat': process.env.amq_heartbeat,
      },
    };
  }

 /**
  * Ensures Broker Connectivity
  * @param {ActiveMQSender|ActiveMQReceiver} - client
  * @returns {Promise} client
  */
  static async connect(client) {
    try {
      // Ensure Connection Manager
      client.connectionManager = client.connectionManager || new ActiveMQConnection();

      // Ensure Connection
      await client.connectionManager.connection;

      // Ensure Channel
      client.channel = await client.connectionManager.channel;
    } catch (e) {
      console.log(`Connection Error: ${e.message}`);
    }
    return client;
  }
}

export default ActiveMQConnection;
