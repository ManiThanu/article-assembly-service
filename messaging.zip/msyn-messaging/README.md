# BLOOMBERG MSYN MESSAGING
This project will be responsible for maintaining the messaging integrations for all of the Bloomberg Media Syndication Platform's Node.js services.

Rationale: Given that the overall architecture of The Platform is message driven, it is necessary that all of The Platform's micro-services have integrations with our main messaging broker (currently ActiveMQ). Rather than maintaining an integration per service (i.e. copying & pasting integration code across numerous code bases), it makes sense to extract the logic out into a sharable dependency so that we can maintain a single set of code and re-use it as much as we'd like via a single line include in our service applications.

## Setup
### RabbitMQ
    $ brew install rabbitmq
    $ rabbitmq-plugins disable rabbitmq_mqtt
    $ rabbitmq-plugins disable rabbitmq_stomp
    $ sudo rabbitmq-server

Admin UI:

    http://localhost:15672
    Username: guest
    Password: guest

### ActiveMQ
    $ brew install activemq
    $ brew services start activemq

Admin UI:

    http://localhost:8161/admin
    Username: admin
    Password: admin

## Installing
    $ npm install msyn-messaging --save

## Publishing
### Step 1: Obtain NPM Credentials
    $ curl -u synusr:askmaniforpw https://artprod.dev.bloomberg.com/artifactory/api/npm/auth

### Step 2: Update .npmrc
Add the response from Step 1 to the `.npmrc` file in your home directory.

### Step 3: Publish
    $ npm publish --registry https://artprod.dev.bloomberg.com/artifactory/api/npm/bb-npmjs-local

Source: https://cms.prod.bloomberg.com/team/pages/viewpage.action?pageId=491036581#Artifactory-Npm(JavascriptPackageManager)-NPMregistryforpublishingpackages

## Configuration
As of now, all connection configurations are handled via ENV variables. This will more than likely change in the future but for now please use the following:

### RabbitMQ
    RABBITMQ_USERNAME="guest"
    RABBITMQ_PASSWORD="guest"
    RABBITMQ_HOST="localhost"
    RABBITMQ_PORT="5672"
    RABBITMQ_VHOST="testing"
    RABBITMQ_HEARTBEAT="5"

### ActiveMQ
    ACTIVEMQ_USERNAME="admin"
    ACTIVEMQ_PASSWORD="password"
    ACTIVEMQ_HOST="localhost"
    ACTIVEMQ_PORT="61613"
    ACTIVEMQ_HEARTBEAT="5000,5000"

## Usage
Coming Soon (for now please look at this project's tests)

## Known Limitations
- RabbitMQ Topics Currently Unsupported

## Contributing
Want to help?

1. Fork it!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push upstream my-new-feature`
5. Submit a pull request

## Support
Find a bug? Please create a new issue in Github.
