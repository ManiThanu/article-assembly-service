import 'babel-polyfill';
import glob   from 'glob';
import Mocha  from 'mocha';

// Ensure Testing Env
process.env.NODE_ENV = 'testing';

// Apply Default Testing Configs
Object.assign(process.env, {
  // RabbitMQ
  rmq_username: 'guest',
  rmq_password: 'guest',
  rmq_hosts: "['localhost']",
  rmq_port: '5672',
  rmq_heartbeat: '5',
  // activemq
  amq_username: 'admin',
  amq_password: 'password',
  amq_hosts: "['localhost']",
  amq_port: '61613',
  amq_heartbeat: '5000,5000',
});

// Create New Mocha Instance
const mocha = new Mocha({ reporter: 'spec', timeout: 10000 });

// Run Suite
glob('tests/**/*.js', (err, files) => {
  files.forEach(f => mocha.addFile(f));
  mocha.run(failures => process.exit(failures));
});
